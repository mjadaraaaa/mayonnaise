<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\User;
use App\Models\Rating;
use Exception;
use Illuminate\Foundation\Auth\User as AuthUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RatingController extends Controller
{
    public function handleRating(Request $request)
    {
        try {
            $user = Auth::user();
            $rated_user = $request->rated_id;
            $existing = Rating::where('rated_id', $rated_user)
                ->where('user_id', $user->id)
                ->first();

            if ($existing) {

                $user = User::where('id', $rated_user)->first();
                $user->update(['rating_sum' =>  $user->rating_sum + $request->rating - $existing->rating,]);
                $user->update(['average_rating' => ($user->rating_sum / $user->rating_count),]);


                $existing->update([

                    'rating' => $request->rating,
                    'content'=>$request->input('content',$existing->content),

                ]);
                return response()->json([
                    'status' => 'success',
                    'message' => 'rating edited successfully',
                    'rating' => $existing,
                ]);
            }

            $rating = Rating::create([
                'rating' => $request->rating,
                'rated_id' => $rated_user,
                'user_id' => $user->id,
                "content" => $request->content,
            ]);
            $user =User::where('id', $rated_user)->first();


            $user->update(['rating_count' => $user->rating_count  + 1,]);


            $user->update(['rating_sum' =>  $user->rating_sum + $request->rating,]);


            $user->update(['average_rating' => $user->rating_sum / $user->rating_count,]);
            
            

            return response()->json([
                'status' => 'success',
                'message' => 'user rated successfully',
                'rating' => $rating,
            ]);
        } catch (Exception $ex) {
            return response()->json([
                'status' => 'error',
                'message' => 'an error occured while trying to rate',
            ]);
        }
    }
    
     public function getUserRatings($user_id){
         
         
         try{
            
            
            $user = User::findorfail($user_id);
            $ratings = Rating::where('rated_id',$user->id)->get();
            
           
            return response()->json([
                'status' => 'success',
                'message' => 'user ratings successfully retrived',
                'ratings' => $ratings,
            ]);
             
             
         }catch(Exception $ex){
        
                  
            return response()->json([
                'status' => 'error',
                'message' =>  "an error occured while trying to get user rating",
            ]);
        
             
         }
         
     }
     
     
     public function deleteRating($rating_id){
         
         
         try{
             $user= Auth::user();
            
            $rating = Rating::findorfail($rating_id);
            
            $rated_user = User::findorfail($rating->rated_id);

   $rating->delete();
            
            $rated_user ->update([
                "rating_count"=> $rated_user->rating_count -1 ,
               
                


            ]);

            $rated_user ->update([
                
                "rating_sum"=> $rated_user->rating_sum - $rating->rating ,
                


            ]);

            if( $rated_user -> rated_count == 0 ){

                 
            $rated_user ->update([
                
                "average_rating"=> 0 ,
                


            ]);

            
            return response()->json([
                'status' => 'success',
                'message' => 'rating successfully deleted',
              
            ]);
             

            }
            
            $rated_user ->update([
                
                "average_rating"=> $rated_user->rating_sum / $rated_user->rating_count ,
                


            ]);
            


         
            
            return response()->json([
                'status' => 'success',
                'message' => 'rating successfully deleted',
              
            ]);
             
             
         }catch(Exception $ex){
        
                  
            return response()->json([
                'status' => 'error',
                'message' =>  "an error occured while trying to delete rating",
            ]);
        
             
         }
         
     }
     
     
     
    
    
}
