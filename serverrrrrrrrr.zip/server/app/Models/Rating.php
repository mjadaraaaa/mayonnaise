<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    use HasFactory;


    protected $fillable = ['rating', 'content', 'user_id', 'rated_id',];



    public function activities()
    {
        return $this->belongsTo(Activity::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    
    public function rated(){
         return $this->belongsTo(User::class,'rated_id');
    }
    
    
}
